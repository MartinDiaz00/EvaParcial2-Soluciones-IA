from dataclasses import dataclass
import os
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT_DIR / 'data'
OUTPUTS_DIR = ROOT_DIR / 'outputs'
MEMORY_FILE = OUTPUTS_DIR / 'memory_store.json'

@dataclass
class Settings:
    app_name: str = 'HealthTech Agentic RAG EP2'
    model_name: str = os.getenv('MODEL_NAME', 'gpt-4o-mini')
    github_token: str = os.getenv('GITHUB_TOKEN', '')
    use_external_llm: bool = os.getenv('USE_EXTERNAL_LLM', 'false').lower() == 'true'
    top_k: int = int(os.getenv('TOP_K', '3'))

settings = Settings()
OUTPUTS_DIR.mkdir(exist_ok=True)
