from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re
from typing import List

from .config import DATA_DIR, settings

@dataclass
class DocumentChunk:
    source: str
    title: str
    content: str
    score: float = 0.0

def _normalize(text: str) -> list[str]:
    text = text.lower()
    text = re.sub(r'[^a-záéíóúñü0-9\s]', ' ', text)
    return [w for w in text.split() if len(w) > 2]

def load_documents() -> List[DocumentChunk]:
    chunks: List[DocumentChunk] = []
    for path in sorted(DATA_DIR.glob('*.md')) + sorted(DATA_DIR.glob('*.txt')):
        raw = path.read_text(encoding='utf-8')
        sections = re.split(r'\n(?=## )', raw)
        for index, section in enumerate(sections):
            title_match = re.search(r'^#+\s*(.+)$', section.strip(), flags=re.MULTILINE)
            title = title_match.group(1).strip() if title_match else f'Sección {index + 1}'
            body = section.strip()
            if len(body) > 40:
                chunks.append(DocumentChunk(source=path.name, title=title, content=body))
    return chunks

def retrieve(query: str, top_k: int | None = None) -> List[DocumentChunk]:
    top_k = top_k or settings.top_k
    query_terms = set(_normalize(query))
    docs = load_documents()
    ranked: List[DocumentChunk] = []
    for doc in docs:
        doc_terms = set(_normalize(doc.content + ' ' + doc.title))
        if not doc_terms:
            continue
        overlap = len(query_terms & doc_terms)
        coverage = overlap / max(len(query_terms), 1)
        density = overlap / max(len(doc_terms), 1)
        score = round((coverage * 0.75 + density * 0.25), 4)
        if score > 0:
            ranked.append(DocumentChunk(doc.source, doc.title, doc.content, score))
    ranked.sort(key=lambda c: c.score, reverse=True)
    return ranked[:top_k]
