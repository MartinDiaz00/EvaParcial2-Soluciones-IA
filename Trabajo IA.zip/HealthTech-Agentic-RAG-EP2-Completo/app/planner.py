from __future__ import annotations
from dataclasses import dataclass
from typing import List

@dataclass
class PlanStep:
    order: int
    action: str
    reason: str

class Planner:
    '''Planificador simple tipo Plan-and-Execute para cumplir IL2.3.'''

    def create_plan(self, question: str) -> List[PlanStep]:
        q = question.lower()
        steps: List[PlanStep] = []
        steps.append(PlanStep(1, 'revisar_memoria', 'Mantener continuidad del flujo conversacional.'))

        needs_rag = any(word in q for word in [
            'healthtech', 'documento', 'rag', 'paciente', 'cita', 'triage', 'soporte',
            'arquitectura', 'pipeline', 'dato', 'evidencia', 'contexto', 'clínico', 'clinico'
        ])
        if needs_rag:
            steps.append(PlanStep(len(steps)+1, 'consultar_rag', 'La pregunta requiere recuperar información documental interna.'))
        else:
            steps.append(PlanStep(len(steps)+1, 'consultar_rag', 'Se consulta la base interna para validar si existe información relacionada.'))

        if any(word in q for word in ['compara', 'decide', 'recomienda', 'prioriza', 'riesgo', 'mejor', 'por qué', 'porque']):
            steps.append(PlanStep(len(steps)+1, 'razonar', 'La consulta exige toma de decisiones o evaluación de alternativas.'))
        else:
            steps.append(PlanStep(len(steps)+1, 'razonar', 'Validar coherencia entre la pregunta, la memoria y los documentos recuperados.'))

        steps.append(PlanStep(len(steps)+1, 'redactar', 'Construir una respuesta clara con trazabilidad.'))
        return steps

    @staticmethod
    def render(plan: List[PlanStep]) -> str:
        return '\n'.join([f'{s.order}. {s.action}: {s.reason}' for s in plan])
