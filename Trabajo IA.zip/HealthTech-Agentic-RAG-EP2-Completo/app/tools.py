from __future__ import annotations
from typing import List
from .knowledge_base import retrieve, DocumentChunk
from .memory_store import MemoryStore

try:
    from langchain_core.tools import tool
except Exception:  # Permite ejecución sin instalar LangChain durante pruebas locales simples.
    def tool(func=None, **kwargs):
        def decorator(f):
            return f
        return decorator(func) if func else decorator

@tool
def rag_search_tool(query: str) -> str:
    '''Busca evidencia en documentos internos de HealthTech.'''
    results: List[DocumentChunk] = retrieve(query)
    if not results:
        return 'No se encontró evidencia documental suficiente.'
    lines = []
    for item in results:
        preview = item.content.replace('\n', ' ')[:420]
        lines.append(f'[{item.source} | {item.title} | score={item.score}] {preview}')
    return '\n'.join(lines)

@tool
def memory_context_tool(_: str = '') -> str:
    '''Recupera memoria conversacional reciente y memoria persistente.'''
    memory = MemoryStore()
    return f'Corto plazo:\n{memory.short_context()}\n\nLargo plazo:\n{memory.long_context()}'

@tool
def writing_tool(content: str) -> str:
    '''Redacta una salida ejecutiva a partir de contenido técnico.'''
    return f'Resumen ejecutivo generado:\n{content}'

def evaluate_evidence(context: str) -> str:
    if 'No se encontró evidencia' in context:
        return 'Evidencia baja: el agente debe advertir falta de información interna.'
    if len(context) > 600:
        return 'Evidencia suficiente: existen múltiples fragmentos recuperados desde documentos internos.'
    return 'Evidencia media: se encontró contexto, pero puede requerir validación humana.'
