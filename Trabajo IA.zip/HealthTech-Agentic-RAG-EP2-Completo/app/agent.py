from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any

from .memory_store import MemoryStore
from .planner import Planner
from .tools import rag_search_tool, memory_context_tool, evaluate_evidence
from .prompts import SYSTEM_PROMPT, ANSWER_TEMPLATE

@dataclass
class AgentResult:
    question: str
    plan: str
    context: str
    memory: str
    answer: str
    trace: str

class HealthTechAgent:
    '''Agente funcional con herramientas, memoria, planificación y RAG.'''

    def __init__(self):
        self.memory = MemoryStore()
        self.planner = Planner()

    def run(self, question: str) -> AgentResult:
        self.memory.add_interaction('usuario', question)
        plan_steps = self.planner.create_plan(question)
        plan_text = self.planner.render(plan_steps)

        memory_text = memory_context_tool.invoke('') if hasattr(memory_context_tool, 'invoke') else memory_context_tool('')
        context_text = rag_search_tool.invoke(question) if hasattr(rag_search_tool, 'invoke') else rag_search_tool(question)
        evidence_status = evaluate_evidence(context_text)

        answer = self._compose_answer(question, context_text, evidence_status)
        self.memory.add_interaction('agente', answer)

        if 'prefiero' in question.lower() or 'recordar' in question.lower():
            self.memory.remember_fact('preferencia_usuario', question)

        trace = (
            'Herramientas usadas: memory_context_tool, rag_search_tool, evaluate_evidence.\n'
            f'Estado de evidencia: {evidence_status}\n'
            'Decisión: responder con base documental y advertir límites cuando corresponda.'
        )
        return AgentResult(question, plan_text, context_text, memory_text, answer, trace)

    def _compose_answer(self, question: str, context: str, evidence_status: str) -> str:
        if 'No se encontró evidencia' in context:
            return (
                'No encontré evidencia suficiente en los documentos internos para responder con total seguridad. '
                'Como decisión del agente, recomiendo ampliar la base documental antes de usar esta respuesta en un contexto clínico u organizacional.'
            )
        return (
            'Según la información recuperada, HealthTech puede responder esta consulta usando su pipeline RAG: '
            'primero recupera documentos internos relevantes, luego valida la coherencia del contexto y finalmente genera una respuesta trazable. '
            f'{evidence_status} Esta respuesta mantiene continuidad mediante memoria conversacional y se entrega como apoyo organizacional, no como diagnóstico médico.'
        )

    def formatted_response(self, question: str) -> str:
        result = self.run(question)
        return ANSWER_TEMPLATE.format(
            question=result.question,
            plan=result.plan,
            context=result.context,
            memory=result.memory,
            answer=result.answer,
            trace=result.trace,
        )
