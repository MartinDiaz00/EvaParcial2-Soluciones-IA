from app.agent import HealthTechAgent


def test_agent_returns_plan_and_context():
    agent = HealthTechAgent()
    result = agent.run('¿Qué hace el sistema HealthTech RAG?')
    assert 'consultar_rag' in result.plan
    assert len(result.answer) > 20
    assert 'Herramientas usadas' in result.trace


def test_agent_memory_continuity():
    agent = HealthTechAgent()
    agent.run('Recordar que el área prioritaria es soporte de pacientes')
    result = agent.run('¿Qué recordabas de la conversación?')
    assert 'soporte de pacientes' in result.memory.lower() or len(result.memory) > 0
