# Diseño de prompts - EP2

## Prompt del sistema
Define rol, límites y criterios de respuesta. Se usa para mantener respuestas coherentes con el contexto HealthTech.

## Prompt de planificación
Indica al agente que primero clasifique la tarea y luego decida si debe usar memoria, RAG, razonamiento o redacción.

## Prompt de seguridad
Obliga a declarar falta de evidencia y evitar diagnósticos médicos.

## Mejora frente a EP1
En la EP1 el feedback indicó falta de mayor desarrollo en diseño de prompts. En esta versión se separan prompts por responsabilidad: sistema, planificación, respuesta y seguridad.
