# Informe Técnico EP2 - HealthTech Agentic RAG

**Asignatura:** ISY0101 - Ingeniería de Soluciones con IA  
**Proyecto:** HealthTech Agentic RAG  
**Continuidad:** Evaluación Parcial 1 - HealthTech RAG Project

## 1. Introducción

Este proyecto corresponde a la segunda etapa del sistema HealthTech RAG desarrollado en la Evaluación Parcial 1. En la etapa anterior se diseñó un pipeline RAG orientado a consultar documentos internos de una organización HealthTech. Para la Evaluación Parcial 2, el sistema se extiende hacia un agente funcional capaz de integrar herramientas de consulta, memoria, razonamiento, planificación y trazabilidad.

La mejora responde al feedback recibido: se fortalece la evidencia de funcionamiento, se profundiza el pipeline, se separa el diseño de prompts y se documenta con mayor detalle la arquitectura implementada.

## 2. Objetivo de la solución

El objetivo es implementar un agente organizacional que apoye consultas administrativas y operativas en HealthTech mediante recuperación de documentos internos. El agente no reemplaza criterios médicos, sino que actúa como apoyo documental y organizacional, entregando respuestas basadas en evidencia interna.

## 3. Arquitectura del agente

La arquitectura se compone de los siguientes módulos:

| Componente | Función |
|---|---|
| Manager Agent | Recibe la consulta y coordina el flujo general. |
| Planner | Define los pasos de ejecución según la solicitud. |
| RAG Tool | Recupera información desde documentos internos. |
| Memory Store | Mantiene historial conversacional y datos persistentes. |
| Evidence Evaluator | Determina si la evidencia recuperada es suficiente. |
| Response Generator | Redacta la respuesta final con trazabilidad. |

El flujo general es: usuario -> agente -> planificación -> memoria/RAG -> evaluación -> respuesta final.

## 4. Herramientas y memoria

El agente integra herramientas de consulta y razonamiento. La herramienta RAG busca información en la base documental de HealthTech, mientras que la herramienta de memoria permite mantener continuidad entre preguntas. La memoria de corto plazo almacena interacciones recientes y la memoria de largo plazo conserva datos relevantes en un archivo JSON.

Esto permite que el agente no funcione como una respuesta aislada, sino como un sistema con estado capaz de continuar un flujo prolongado.

## 5. Planificación y toma de decisiones

La planificación se implementa mediante un enfoque Plan-and-Execute. Antes de responder, el agente genera una secuencia de acciones: revisar memoria, consultar documentos, razonar sobre evidencia y redactar una respuesta. Si la evidencia es insuficiente, el agente informa la limitación y recomienda validación humana.

Este comportamiento demuestra toma de decisiones adaptativa, ya que el agente ajusta su respuesta según el contexto recuperado y la calidad de la evidencia disponible.

## 6. Diseño de prompts

A diferencia de la versión anterior, los prompts fueron separados por responsabilidad:

- prompt del sistema: define rol y límites del agente;
- prompt de planificación: guía la selección de acciones;
- prompt de seguridad: evita respuestas clínicas no validadas;
- plantilla de respuesta: ordena salida, plan, contexto, memoria y trazabilidad.

Esta separación mejora la mantenibilidad y permite explicar con mayor claridad cómo el agente decide y responde.

## 7. Evidencia de funcionamiento

El proyecto incluye una demo ejecutable mediante `python scripts/run_demo.py` y pruebas automáticas mediante `pytest`. Además, la carpeta `evidencias/` documenta casos de prueba relacionados con consulta RAG, memoria conversacional y toma de decisiones ante información sensible.

## 8. Conclusión

La solución implementada transforma el proyecto RAG inicial en un agente funcional alineado con los requisitos de la EP2. El sistema integra herramientas, memoria, planificación y documentación técnica. Además, corrige las principales debilidades observadas en la EP1 al incorporar evidencia concreta, mayor profundidad en el pipeline y prompts mejor estructurados.

## 9. Referencias

LangChain. (2025). LangChain documentation. https://python.langchain.com/  
CrewAI. (2025). CrewAI documentation. https://docs.crewai.com/  
Material de clases ISY0101. (2025). Arquitectura y Frameworks de Agentes; Sistemas de Memoria; Estrategias de Planificación y Orquestación.
