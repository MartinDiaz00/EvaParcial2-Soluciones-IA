# Diagramas del proyecto

Los archivos `.mmd` se pueden visualizar en GitHub o en https://mermaid.live.

- `arquitectura_ep2.mmd`: arquitectura general del agente.
- `flujo_trabajo_ep2.mmd`: flujo de ejecución desde la consulta hasta la respuesta.
