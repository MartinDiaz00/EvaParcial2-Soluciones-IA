from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.agent import HealthTechAgent

questions = [
    '¿Qué hace el sistema HealthTech RAG?',
    '¿Cómo usa memoria el agente?',
    'Recomienda una respuesta para soporte de pacientes usando evidencia interna.'
]

agent = HealthTechAgent()
for question in questions:
    print('=' * 80)
    print(agent.formatted_response(question))
