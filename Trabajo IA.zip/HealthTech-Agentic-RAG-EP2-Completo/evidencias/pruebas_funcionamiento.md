# Evidencias de funcionamiento

## Prueba 1 - Consulta RAG
Entrada:
```text
¿Qué hace el sistema HealthTech RAG?
```
Resultado esperado:
- El agente genera un plan.
- Consulta documentos internos.
- Entrega respuesta con trazabilidad.

## Prueba 2 - Memoria conversacional
Entrada 1:
```text
Recordar que el área prioritaria es soporte de pacientes.
```
Entrada 2:
```text
¿Qué recordabas de la conversación?
```
Resultado esperado:
- El agente recupera historial reciente.
- Se evidencia continuidad conversacional.

## Prueba 3 - Toma de decisiones
Entrada:
```text
Recomienda cómo responder una consulta sensible de un paciente.
```
Resultado esperado:
- El agente consulta documentos.
- Evalúa límites de seguridad.
- Recomienda derivación humana si corresponde.

## Comando para generar evidencia en consola
```bash
python scripts/run_demo.py
```

## Comando para pruebas automáticas
```bash
pytest
```
