# HealthTech Agentic RAG - EP2

Continuación del proyecto **HealthTech RAG Project** desarrollado en la EP1. En esta segunda evaluación el sistema se transforma en un **agente funcional** capaz de usar herramientas, memoria, recuperación de contexto, planificación y trazabilidad.

## 1. Objetivo del proyecto

Implementar un agente organizacional para HealthTech que apoye consultas administrativas y operativas mediante:

- consulta de documentos internos mediante RAG;
- memoria conversacional de corto plazo;
- memoria persistente de largo plazo;
- planificación tipo Plan-and-Execute;
- evaluación de evidencia antes de responder;
- trazabilidad del flujo ejecutado.

Esta versión responde directamente al feedback recibido en la EP1: se agregan evidencias de funcionamiento, mayor profundidad del pipeline, diseño de prompts separado por responsabilidad y explicación detallada de la arquitectura.

## 2. Relación con EP1

En la EP1 se diseñó un pipeline RAG para HealthTech. La retroalimentación indicaba que existía una buena base conceptual y una arquitectura clara, pero faltaba mayor profundidad, evidencia concreta y desarrollo de prompts.

En la EP2 se mantiene el mismo caso organizacional y se agregan componentes agenticos:

| Elemento EP1 | Mejora EP2 |
|---|---|
| RAG documental | RAG usado como herramienta del agente |
| Arquitectura conceptual | Arquitectura ejecutable con módulos Python |
| Prompts generales | Prompts separados: sistema, planificación y seguridad |
| Poca evidencia | Carpeta `evidencias/` y demo ejecutable |
| Pipeline básico | Planificación, memoria y trazabilidad |

## 3. Arquitectura

El sistema se organiza en módulos:

```text
Usuario
  -> Manager Agent
      -> Planner Plan-and-Execute
      -> Memory Store
      -> RAG Search Tool
      -> Evidence Evaluator
      -> Response Generator
```

Ver diagramas en:

- `diagrams/arquitectura_ep2.mmd`
- `diagrams/flujo_trabajo_ep2.mmd`

## 4. Estructura del proyecto

```text
HealthTech-Agentic-RAG-EP2-Completo/
├── app/
│   ├── agent.py
│   ├── api.py
│   ├── config.py
│   ├── knowledge_base.py
│   ├── main.py
│   ├── memory_store.py
│   ├── planner.py
│   ├── prompts.py
│   └── tools.py
├── data/
│   ├── healthtech_internal_docs.md
│   └── procesos_soporte_pacientes.md
├── diagrams/
│   ├── arquitectura_ep2.mmd
│   └── flujo_trabajo_ep2.mmd
├── docs/
│   ├── INFORME_EP2_HealthTech_Agentic_RAG.docx
│   └── INFORME_EP2_HealthTech_Agentic_RAG.md
├── evidencias/
│   └── pruebas_funcionamiento.md
├── prompts/
│   └── prompt_design.md
├── scripts/
│   └── run_demo.py
├── tests/
│   ├── test_agent.py
│   └── test_queries.md
├── main.py
├── requirements.txt
└── .env.example
```

## 5. Instalación

Crear entorno virtual:

```bash
python -m venv .venv
```

Activar entorno en Windows:

```bash
.venv\Scripts\activate
```

Instalar dependencias:

```bash
pip install -r requirements.txt
```

## 6. Ejecución por consola

```bash
python main.py
```

Ejemplo de consulta:

```text
¿Qué hace el sistema HealthTech RAG?
```

## 7. Ejecutar demo automática

```bash
python scripts/run_demo.py
```

## 8. Ejecutar API FastAPI

```bash
uvicorn app.api:app --reload
```

Luego abrir:

```text
http://127.0.0.1:8000/docs
```

Endpoint principal:

```text
POST /agent/query
```

Body ejemplo:

```json
{
  "question": "¿Cómo usa memoria el agente?"
}
```

## 9. Pruebas

```bash
pytest
```

## 10. Herramientas del agente

| Herramienta | Función |
|---|---|
| `rag_search_tool` | Consulta documentos internos |
| `memory_context_tool` | Recupera memoria de corto y largo plazo |
| `evaluate_evidence` | Evalúa si existe evidencia suficiente |
| `writing_tool` | Apoya redacción ejecutiva |

## 11. Memoria

La memoria se guarda en:

```text
outputs/memory_store.json
```

Incluye:

- corto plazo: últimas interacciones;
- largo plazo: datos persistentes o preferencias relevantes.

## 12. Planificación

El agente usa una estrategia simple tipo **Plan-and-Execute**:

1. revisar memoria;
2. consultar RAG;
3. razonar sobre evidencia;
4. redactar respuesta final.

## 13. Límites de seguridad

El agente no entrega diagnósticos médicos. Si la consulta requiere criterio clínico, debe recomendar derivación humana. Su uso está enfocado en apoyo organizacional, administrativo y documental.

## 14. Referencias

- LangChain. Documentación oficial de agentes y tools.
- CrewAI. Documentación oficial de orquestación de agentes.
- Material de clases ISY0101: Arquitectura y Frameworks de Agentes; Sistemas de Memoria; Planificación y Orquestación.
